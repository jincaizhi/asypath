# AsyPath
第一阶段模拟庇护训练平台

## 功能
- 上传 I-589 自述书
- 自动生成AI问题
- 模拟问答
- 可导出训练报告

## 快速部署
1. 安装依赖：`npm install express multer cors`
2. 启动服务：`node server.js`
3. 在浏览器打开 `http://localhost:3000`