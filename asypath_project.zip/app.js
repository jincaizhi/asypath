function uploadFile() {
  const input = document.getElementById('fileInput');
  const file = input.files[0];
  const formData = new FormData();
  formData.append('file', file);

  fetch('/api/upload', {
    method: 'POST',
    body: formData,
  })
  .then(res => res.json())
  .then(data => {
    const qaSection = document.getElementById('qaSection');
    qaSection.innerHTML = '';
    data.questions.forEach((q, index) => {
      const div = document.createElement('div');
      div.innerHTML = `<strong>${q.role}:</strong> ${q.question}<br><textarea rows="3" cols="50" placeholder="你的回答..."></textarea><br><br>`;
      qaSection.appendChild(div);
    });
  });
}