const express = require('express');
const multer = require('multer');
const cors = require('cors');
const app = express();
const upload = multer({ dest: 'uploads/' });
app.use(cors());
app.use(express.static('.'));

app.post('/api/upload', upload.single('file'), (req, res) => {
  const questions = [
    { role: '政府律师', question: '你为什么现在才申请庇护？' },
    { role: '法官', question: '你能证明你在中国受到了迫害吗？' },
    { role: '律师', question: '请详细讲述你是如何逃离中国的。' },
  ];
  res.json({ questions });
});

app.listen(3000, () => console.log('Server running on port 3000'));